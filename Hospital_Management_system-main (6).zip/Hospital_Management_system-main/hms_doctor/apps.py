from django.apps import AppConfig


class HmsDoctorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hms_doctor'
