from django.db import models
from hms.models import *

# Create your models here.
